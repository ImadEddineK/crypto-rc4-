package rc4;

import java.util.ArrayList;
import java.util.List;
import java.lang.*;
public class test {


	public static void main(String[] args) {
        double o = fun(6.5 , 5.25 , 4 , 9);
        System.out.println(o);
    }
    
    public static double fun(double i, double j, double y, double k){
        double m = Math.pow(i-y,2);
        double n = Math.pow(j-k,2);
        return m+n;
    }	

}
