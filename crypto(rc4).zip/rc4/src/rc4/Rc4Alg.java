package rc4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Rc4Alg {
	
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		// initialisation des variables utilis�s:
		int combienOctet; int size; int[] FlotPaleatoire;
		System.out.println("est ce que la longueur de cl� est 16 octet ou 32 octet ");
		// pr�paration de scanaire:
		combienOctet = sc.nextInt();
		
		// On va stocker la chaine de caract�res qui repr�sente la cl� sur key0:
		String key0 = donnerCle(combienOctet);
		System.out.println("cette chaine de caract�res est la cl� initiale "+key0);
		// la conversation du cl� de chaine de caract�res en un tableau d'entier
		int[] key1 =chaineToint(key0);
		
		
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		// La partie du key shedule :
		int[] s = new int[256]; int swap;
		for(int i=0;i<256;i++) {s[i]=i;}
		int j=0;  
		
		System.out.println("le tableau s avant le changement ");
		for(int i =0;i<256;i++) {System.out.print(s[i]+" ");}
		
		for(int i =0;i<256;i++) {
			j = (j+s[i]+key1[ i % key1.length ]) % 256;
			
			swap = s[i];  s[i]=s[j];   s[j] = swap;
		}
		
		System.out.println("\n le tableau s apres le changement \n");
		for(int i =0;i<256;i++) {System.out.print(s[i]+" ");}
		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// La g�n�ration du flot pseudo�al�atoire
		System.out.println("\n donnez la taille du flot d�sir� :");
		size=sc.nextInt();
		FlotPaleatoire = Gener_Stream(s,size);
		
		System.out.println("\n le flot g�n�r� : ");
		for(int i =0;i<10;i++) {System.out.print(FlotPaleatoire[i]+" ");}
		
		// 
		
		
		String plainText = null;
		
		System.out.println("\n donnez le chemin de fichier ");
		String chemin=sc.next();
		
		try {
			BufferedReader lecf= new BufferedReader(new FileReader(chemin));
			plainText = lecf.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		int[] plainText_Int = chaineToint(plainText);
		
		
		// le chiffrement:
		int[] ciferText_Int = new int[plainText_Int.length]; char c; 
		System.out.println("le message chifr� : ");
		for(int i=0;i<plainText_Int.length;i++) {
			ciferText_Int[i] = plainText_Int[i] ^ FlotPaleatoire[i];
			c = (char) ciferText_Int[i];
			System.out.print(c);
		}
		
		// le d�chiffrement:
		System.out.println("\n le message claire de nouveau : ");
		for(int i=0;i<plainText_Int.length;i++) {
			int o = ciferText_Int[i] ^ FlotPaleatoire[i];
			c = (char) o;
			System.out.print(c);
		}
		
		
		
		
		
		
		
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// la fonction donnerCle permet a l'utilisateur de donner la cl� initiale utilis� pour faire le key shedule :
	// l'utilisateur a le droit de donner la cl� sous forme d'une chaine de caract�re.
	
	public static String donnerCle(int longeur) {
		
		System.out.println("SVP entrez la cl� sous forme d'une chaine de caract�res : \n chaque caract�re sera ult�rieurement consid�r� "
				+ "comme un octet pour compl�ter les �tapes de l'algorithme.");

		
		String s = ""; 
		for(int i=0;i<longeur;i++) {
			System.out.println("entrez l'octet numero : "+i);
			s=s.concat(sc.next());
		}
		return s;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// la fonction chaineToint est utilis� pour faire la conversation des chaines de caract�res en entier, chaque caract�re est conver� sous forme
	// d'un entier selon le codage ASCII et stock� sur 1 octet pour l'utilis� comme un element de la cl� initiale.
	
	public static int[] chaineToint(String s) {
		int[] a = new int[s.length()];
		for(int i =0;i<s.length();i++) {
			a[i]=(int) s.charAt(i);
		}
		return a;
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// la fonction Gener_Stream est utilis�e pour g�n�rer le flot pseudo�al�atoire utilis� pour le chiffrement
	
	public static int[] Gener_Stream(int[] s, int size) {
		int[] flot = new int[size];
		int i=-1,j=0,swap;
		while(i<size-1) {
			i = (i+1) % 256;
			j = (j + s[i]) % 256;
			
			swap=s[i];   s[i]=s[j];     s[j]=swap;
			
			flot[i] = s[ (s[i]+s[j]) % 256 ];
		}
		
		return flot;
	}
	
	
	

}
